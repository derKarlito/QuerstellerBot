from crontab import CronTab

class CronjobHelper:
    crontab = CronTab(user='notyou')
    job = crontab.new(command='python /home/RandomStuff/QuerstellerBot/src/CronJob.py')
    job.minute.every(1)
    crontab.write()
    print("Cronjob written!")