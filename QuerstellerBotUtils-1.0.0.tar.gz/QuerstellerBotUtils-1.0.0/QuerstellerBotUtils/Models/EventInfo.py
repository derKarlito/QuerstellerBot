import datetime
class EventInfo():
    def __init__(self, Plz, Uhrzeit, Adresse, Art, Veranstalter, Datum, Ort):
        self.Plz = Plz
        self.Time = Uhrzeit
        self.Date = Datum
        self.Place = Adresse
        self.How = Art
        self.Organizer = Veranstalter
        self.Ort = Ort
        self.id = self.calculate_id()
        self.Timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    def calculate_id(self):
        id = str(str(self.Place)+str(self.Plz)+str(self.Ort)+str(self.How)+str(self.Date)).encode('utf-8')
        return id.hex()