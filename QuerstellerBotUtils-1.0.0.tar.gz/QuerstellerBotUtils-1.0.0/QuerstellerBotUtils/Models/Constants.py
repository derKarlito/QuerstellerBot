from enum import Enum


class Constants(str, Enum):
    JA = "ja"
    NEIN = "nein"
