from enum import Enum


class QuestionStates(Enum):
    LOCATION = 1
    MORELOCATION = 2
    ADDLOCATION = 3
