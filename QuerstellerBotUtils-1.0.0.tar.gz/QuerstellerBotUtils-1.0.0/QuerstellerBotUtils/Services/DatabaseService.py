import mysql.connector
from mysql.connector import Error
from QuerstellerBotUtils.Models.EventInfo import EventInfo
import datetime

class DatabaseService:
    def __init__(self):
        self.connect()

    def connect(self):
        """ Connect to MySQL database """
        connection = None
        try:
            return mysql.connector.connect(host='localhost',
                                           database='QuerstellerUser',
                                           user='notyou',
                                           password='HiJk26.10')

        except Error as e:
            print(e)





    def insert_events(self,events):
        db = self.connect()
        cursor = db.cursor()
        sql = "INSERT IGNORE INTO `event` (`id`,`plz`, `time`, `place`, `how`, `organizer`, `city`,`timeadded`) VALUES (%s,%s, %s, %s, %s, %s, %s, %s)"
        try:
            for event in events:
                cursor.execute(sql,(event.id, event.Plz,event.Date,event.Place,event.How,event.Organizer,event.Ort,event.Timestamp))
                db.commit()


        except Error as e:
            print(e)
            db.rollback()

        finally:

            print("done inserting events")
            cursor.close()
            db.close()



    def insert_user(self,user):
        #TODO: Check for TypeError
        db = self.connect()
        cursor = db.cursor()

        sqlUser = "INSERT INTO `user` (`id`, `update`) VALUES (%s, %s)"
        sqlLocations = "INSERT INTO `location` (`id`, `name`) VALUES (%s, %s)"
        try:
            # Executing the SQL command
            cursor.execute(sqlUser,(user.id, str(user.update)))
            for location in user.locations:
                cursor.execute(sqlLocations,(user.id,location))

            # Commit your changes in the database
            db.commit()
            print("Inserted User")

        except Error as e:
            # Rolling back in case of error
            print("Failed to insert user in Database:")
            print(e)
            db.rollback()

        # Closing the connection
        finally:
            cursor.close()
            db.close()


    def update_user_locations(self,user_id,locations):
        db = self.connect()
        cursor = db.cursor()
        sql = "INSERT IGNORE INTO `location` (`id`,`name`) VALUES (%s, %s)"
        try:
            # Executing the SQL command
            for location in locations:
                cursor.execute(sql,(user_id, location))

            # Commit your changes in the database
            db.commit()
            print("Updated User Locations")

        except Error as e:
            # Rolling back in case of error
            print("Failed to update user location in Database:")
            print(e)
            db.rollback()

        # Closing the connection
        finally:
            cursor.close()
            db.close()


    def get_events_for_locations(self,locations):
        db_events = []
        db = self.connect()
        cursor = db.cursor()
        sql = "SELECT * FROM event WHERE event.city = "
        for location in locations:
            try:
                cursor.execute(sql+"'"+str(location)+"'")
                output = cursor.fetchall()
                db_events.append(output)

            except Error as e:
                print(e)
                db.rollback()

        cursor.close()
        db.close()
        events = []
        for event in db_events:
            if(len(event)>0):
                Plz,Uhrzeit,Adresse,Art,Veranstalter,Datum,Ort = event[0]
                events.append(EventInfo(Plz,Uhrzeit,Adresse,Art,Veranstalter,Datum,Ort))

        return events

    def get_all_users(self):
        db_user = []
        db = self.connect()
        cursor = db.cursor()
        sql = "SELECT * FROM user"
        try:
            cursor.execute(sql)
            output = cursor.fetchall()
            db_user.append(output)

        except Error as e:
            print(e)
            db.rollback()

        cursor.close()
        db.close()

        return db_user;

    def get_locations_for_user(self,userId):
        db = self.connect()
        cursor = db.cursor()
        userLocations = []
        sql = "SELECT name FROM location WHERE location.id = "+str(userId)
        try:
            cursor.execute(sql)
            output = cursor.fetchall()
            userLocations.append(output)

        except Error as e:
            print(e)
            db.rollback()

        cursor.close()
        db.close()
        return userLocations




