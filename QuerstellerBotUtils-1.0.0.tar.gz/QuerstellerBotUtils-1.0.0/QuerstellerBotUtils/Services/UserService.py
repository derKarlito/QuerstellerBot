from QuerstellerBotUtils.Helper.StringHelper import StringHelper
from QuerstellerBotUtils.Services.DatabaseService import DatabaseService
from QuerstellerBotUtils.Models.User import User
import telegram.bot




class UserService:
    users = []
    calender = None
    dbService = DatabaseService()
    bot = telegram.bot.Bot(token='1764397833:AAHigJWCNjCuhkYoBP5e8Mptv8ahji78PkU')

    def add_user(self, user):
        self.users.append(user)
        self.dbService.insert_user(user)

    def add_calender(self, calender):
        if calender is not None:
            self.calender = calender

    def check_for_news(self,user):
        if(self.calender != None):
            nextDates = self.calender.get_next_dates(user.locations)
            self.bot.send_message(chat_id=user.update.effective_chat.id, text=StringHelper().get_eventlist_as_message(eventlist=nextDates))

    def add_locations_to_user(self,locations,user_id):
        for x in self.users:
            if x.id == user_id:
                for loc in locations:
                    x.locations.append(loc)
                break
        self.dbService.update_user_locations(user_id,locations)

    def get_user_by_id(self,userChatId):
        for user in self.users:
            if user.update.effective_chat.id == userChatId:
                return user